import React, { useState, useEffect } from 'react';
import './App.css';
import Logo from './logo_design';
import IntervalReminder from './components/IntervalReminder';
import MotivationalQuotes from './components/MotivationalQuotes';
import Achievements from './components/Achievements';

function App() {
  // Load tasks from localStorage or use default
  const [tasks, setTasks] = useState(() => {
    const savedTasks = localStorage.getItem('habithelperTasks');
    if (savedTasks) {
      return JSON.parse(savedTasks);
    } else {
      return [
        { id: 1, name: 'Morning Workout', completed: false, frequency: 'daily' },
        { id: 2, name: 'Read for 30 minutes', completed: false, frequency: 'daily' },
        { id: 3, name: 'Drink water', completed: false, frequency: 'daily' }
      ];
    }
  });
  
  const [activeTab, setActiveTab] = useState('tasks');
  
  // Save tasks to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('habithelperTasks', JSON.stringify(tasks));
  }, [tasks]);
  
  const toggleTaskCompletion = (id) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const addTask = (taskName) => {
    const newTask = {
      id: tasks.length > 0 ? Math.max(...tasks.map(t => t.id)) + 1 : 1,
      name: taskName,
      completed: false,
      frequency: 'daily'
    };
    setTasks([...tasks, newTask]);
  };
  
  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  // Get a random quote for the header
  const getHeaderQuote = () => {
    const quotes = [
      "The secret of getting ahead is getting started.",
      "Small daily improvements are the key to staggering long-term results.",
      "Habits form the foundation of achievement.",
      "Consistency is the key to mastery."
    ];
    return quotes[Math.floor(Math.random() * quotes.length)];
  };

  return (
    <div className="App">
      <header className="App-header">
        <div className="logo-container">
          <Logo />
        </div>
        <h1>HabitHelperPro</h1>
        <p className="quote">{getHeaderQuote()}</p>
      </header>
      
      <div className="tab-navigation">
        <button 
          className={activeTab === 'tasks' ? 'active' : ''} 
          onClick={() => setActiveTab('tasks')}
        >
          Tasks
        </button>
        <button 
          className={activeTab === 'reminders' ? 'active' : ''} 
          onClick={() => setActiveTab('reminders')}
        >
          Reminders
        </button>
        <button 
          className={activeTab === 'quotes' ? 'active' : ''} 
          onClick={() => setActiveTab('quotes')}
        >
          Quotes
        </button>
        <button 
          className={activeTab === 'achievements' ? 'active' : ''} 
          onClick={() => setActiveTab('achievements')}
        >
          Achievements
        </button>
      </div>
      
      <div className="content-area">
        {activeTab === 'tasks' && (
          <div className="tasks-container">
            <h2>Daily Tasks</h2>
            <ul className="task-list">
              {tasks.map(task => (
                <li key={task.id} className={task.completed ? 'completed' : ''}>
                  <input 
                    type="checkbox" 
                    checked={task.completed} 
                    onChange={() => toggleTaskCompletion(task.id)} 
                  />
                  <span>{task.name}</span>
                  <button 
                    className="delete-task-btn" 
                    onClick={() => deleteTask(task.id)}
                  >
                    ×
                  </button>
                </li>
              ))}
            </ul>
            <div className="add-task">
              <input 
                type="text" 
                id="new-task" 
                placeholder="Add a new task..." 
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && e.target.value.trim() !== '') {
                    addTask(e.target.value);
                    e.target.value = '';
                  }
                }}
              />
            </div>
          </div>
        )}
        
        {activeTab === 'reminders' && (
          <IntervalReminder />
        )}
        
        {activeTab === 'quotes' && (
          <MotivationalQuotes />
        )}
        
        {activeTab === 'achievements' && (
          <Achievements tasks={tasks} />
        )}
      </div>
    </div>
  );
}

export default App;
