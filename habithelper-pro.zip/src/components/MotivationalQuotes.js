import React, { useState, useEffect } from 'react';
import './MotivationalQuotes.css';

const MotivationalQuotes = () => {
  const [currentQuote, setCurrentQuote] = useState(() => {
    const savedCurrentQuote = localStorage.getItem('habithelperCurrentQuote');
    if (savedCurrentQuote) {
      return JSON.parse(savedCurrentQuote);
    } else {
      return {
        text: "The secret of getting ahead is getting started.",
        author: "Mark Twain"
      };
    }
  });
  
  const [savedQuotes, setSavedQuotes] = useState(() => {
    const saved = localStorage.getItem('habithelperSavedQuotes');
    if (saved) {
      return JSON.parse(saved);
    } else {
      return [];
    }
  });
  
  const quotes = [
    {
      text: "The secret of getting ahead is getting started.",
      author: "Mark Twain"
    },
    {
      text: "Small daily improvements are the key to staggering long-term results.",
      author: "Unknown"
    },
    {
      text: "Habits form the foundation of achievement.",
      author: "Unknown"
    },
    {
      text: "Consistency is the key to mastery.",
      author: "Unknown"
    },
    {
      text: "We are what we repeatedly do. Excellence, then, is not an act, but a habit.",
      author: "Aristotle"
    },
    {
      text: "Success is the sum of small efforts, repeated day in and day out.",
      author: "Robert Collier"
    },
    {
      text: "The only way to do great work is to love what you do.",
      author: "Steve Jobs"
    },
    {
      text: "Don't wish it were easier. Wish you were better.",
      author: "Jim Rohn"
    },
    {
      text: "You don't have to be great to start, but you have to start to be great.",
      author: "Zig Ziglar"
    },
    {
      text: "The struggle you're in today is developing the strength you need for tomorrow.",
      author: "Robert Tew"
    }
  ];
  
  // Save current quote to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('habithelperCurrentQuote', JSON.stringify(currentQuote));
  }, [currentQuote]);
  
  // Save quotes to localStorage when savedQuotes changes
  useEffect(() => {
    localStorage.setItem('habithelperSavedQuotes', JSON.stringify(savedQuotes));
  }, [savedQuotes]);
  
  // Get a new random quote
  const getRandomQuote = () => {
    let newQuote;
    do {
      const randomIndex = Math.floor(Math.random() * quotes.length);
      newQuote = quotes[randomIndex];
    } while (newQuote.text === currentQuote.text); // Ensure we get a different quote
    
    setCurrentQuote(newQuote);
  };
  
  // Save current quote
  const saveQuote = () => {
    if (!savedQuotes.some(q => q.text === currentQuote.text)) {
      setSavedQuotes([...savedQuotes, currentQuote]);
    }
  };
  
  // Remove a saved quote
  const removeSavedQuote = (index) => {
    const updatedQuotes = [...savedQuotes];
    updatedQuotes.splice(index, 1);
    setSavedQuotes(updatedQuotes);
  };
  
  return (
    <div className="motivational-quotes">
      <div className="current-quote-container">
        <h2>Daily Motivation</h2>
        <div className="quote-card">
          <p className="quote-text">"{currentQuote.text}"</p>
          <p className="quote-author">- {currentQuote.author}</p>
          <div className="quote-actions">
            <button onClick={getRandomQuote} className="refresh-button">
              New Quote
            </button>
            <button onClick={saveQuote} className="save-button">
              Save Quote
            </button>
          </div>
        </div>
      </div>
      
      <div className="saved-quotes-container">
        <h3>Saved Quotes</h3>
        {savedQuotes.length === 0 ? (
          <p className="no-saved-quotes">No saved quotes yet. Save quotes you find inspiring!</p>
        ) : (
          <ul className="saved-quotes-list">
            {savedQuotes.map((quote, index) => (
              <li key={index} className="saved-quote">
                <p className="quote-text">"{quote.text}"</p>
                <p className="quote-author">- {quote.author}</p>
                <button 
                  onClick={() => removeSavedQuote(index)} 
                  className="remove-button"
                >
                  Remove
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default MotivationalQuotes;
