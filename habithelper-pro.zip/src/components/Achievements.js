import React, { useState, useEffect } from 'react';
import './Achievements.css';

const Achievements = ({ tasks }) => {
  const [achievements, setAchievements] = useState(() => {
    const savedAchievements = localStorage.getItem('habithelperAchievements');
    if (savedAchievements) {
      return JSON.parse(savedAchievements);
    } else {
      return [
        { 
          id: 1, 
          name: 'First Steps', 
          description: 'Complete your first task',
          unlocked: false,
          progress: 0,
          target: 1
        },
        { 
          id: 2, 
          name: 'Consistency Champion', 
          description: 'Complete all tasks for 7 days in a row',
          unlocked: false,
          progress: 0,
          target: 7
        },
        { 
          id: 3, 
          name: 'Early Bird', 
          description: 'Complete a task before 8 AM',
          unlocked: false,
          progress: 0,
          target: 1
        },
        { 
          id: 4, 
          name: 'Habit Master', 
          description: 'Maintain a 30-day streak on any habit',
          unlocked: false,
          progress: 0,
          target: 30
        }
      ];
    }
  });
  
  // Check for completed tasks and update achievements
  useEffect(() => {
    const updatedAchievements = [...achievements];
    
    // Check "First Steps" achievement
    if (!updatedAchievements[0].unlocked && tasks.some(task => task.completed)) {
      updatedAchievements[0].progress = 1;
      updatedAchievements[0].unlocked = true;
    }
    
    // Update "Consistency Champion" progress
    const allTasksCompleted = tasks.length > 0 && tasks.every(task => task.completed);
    if (allTasksCompleted) {
      updatedAchievements[1].progress = Math.min(updatedAchievements[1].progress + 1, 7);
      if (updatedAchievements[1].progress >= 7) {
        updatedAchievements[1].unlocked = true;
      }
    }
    
    // Check "Early Bird" achievement
    const currentHour = new Date().getHours();
    if (!updatedAchievements[2].unlocked && currentHour < 8 && tasks.some(task => task.completed)) {
      updatedAchievements[2].progress = 1;
      updatedAchievements[2].unlocked = true;
    }
    
    // Update "Habit Master" progress based on longest streak
    // This is simplified - in a real app we'd track each habit's streak
    if (allTasksCompleted) {
      updatedAchievements[3].progress = Math.min(updatedAchievements[3].progress + 1, 30);
      if (updatedAchievements[3].progress >= 30) {
        updatedAchievements[3].unlocked = true;
      }
    }
    
    setAchievements(updatedAchievements);
  }, [tasks]);
  
  // Save achievements to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('habithelperAchievements', JSON.stringify(achievements));
  }, [achievements]);
  
  return (
    <div className="achievements-container">
      <h2>Your Achievements</h2>
      
      <div className="achievement-grid">
        {achievements.map(achievement => (
          <div 
            key={achievement.id} 
            className={`achievement-card ${achievement.unlocked ? 'unlocked' : 'locked'}`}
          >
            <h3>{achievement.name}</h3>
            <p>{achievement.description}</p>
          </div>
        ))}
      </div>
      
      <div className="progress-section">
        <h3>Achievement Progress</h3>
        
        {achievements.filter(a => !a.unlocked).map(achievement => (
          <div key={achievement.id} className="progress-item">
            <h4>{achievement.name}</h4>
            <div className="progress-bar-container">
              <div 
                className="progress-bar" 
                style={{ width: `${(achievement.progress / achievement.target) * 100}%` }}
              ></div>
            </div>
            <div className="progress-text">
              <span>{achievement.progress} {achievement.progress === 1 ? 'day' : 'days'}</span>
              <span>{achievement.target} {achievement.target === 1 ? 'day' : 'days'}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Achievements;
