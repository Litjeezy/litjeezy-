import React, { useState, useEffect } from 'react';
import './IntervalReminder.css';

const IntervalReminder = () => {
  // Load reminders from localStorage or use default
  const [reminders, setReminders] = useState(() => {
    const savedReminders = localStorage.getItem('habithelperReminders');
    if (savedReminders) {
      return JSON.parse(savedReminders);
    } else {
      return [
        { 
          id: 1, 
          title: '10 Squats', 
          interval: 45, // minutes
          duration: 8, // hours
          active: false,
          nextReminder: null,
          completedCount: 0
        }
      ];
    }
  });
  
  const [newReminder, setNewReminder] = useState({
    title: '',
    interval: 45,
    duration: 8
  });

  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Update current time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      checkReminders();
    }, 60000); // Check every minute
    
    return () => clearInterval(timer);
  }, []);
  
  // Save reminders to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('habithelperReminders', JSON.stringify(reminders));
  }, [reminders]);
  
  // Check if any reminders need to be triggered
  const checkReminders = () => {
    const updatedReminders = reminders.map(reminder => {
      if (reminder.active && reminder.nextReminder && new Date() >= new Date(reminder.nextReminder)) {
        // Trigger notification
        if (Notification.permission === "granted") {
          new Notification(`Time for ${reminder.title}!`, {
            body: `Your ${reminder.interval}-minute interval reminder`,
            icon: '/images/logo.svg'
          });
        }
        
        // Calculate next reminder time
        const nextTime = new Date();
        nextTime.setMinutes(nextTime.getMinutes() + reminder.interval);
        
        return {
          ...reminder,
          nextReminder: nextTime.toISOString(),
          completedCount: reminder.completedCount + 1
        };
      }
      return reminder;
    });
    
    setReminders(updatedReminders);
  };
  
  const toggleReminder = (id) => {
    setReminders(reminders.map(reminder => {
      if (reminder.id === id) {
        if (!reminder.active) {
          // Calculate next reminder time when activating
          const nextTime = new Date();
          nextTime.setMinutes(nextTime.getMinutes() + reminder.interval);
          
          return {
            ...reminder,
            active: true,
            nextReminder: nextTime.toISOString(),
            completedCount: 0
          };
        } else {
          // Deactivate
          return {
            ...reminder,
            active: false,
            nextReminder: null
          };
        }
      }
      return reminder;
    }));
  };
  
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewReminder({
      ...newReminder,
      [name]: name === 'title' ? value : parseInt(value, 10)
    });
  };
  
  const addNewReminder = () => {
    if (newReminder.title.trim() === '') return;
    
    const newId = reminders.length > 0 ? Math.max(...reminders.map(r => r.id)) + 1 : 1;
    
    setReminders([
      ...reminders,
      {
        id: newId,
        title: newReminder.title,
        interval: newReminder.interval,
        duration: newReminder.duration,
        active: false,
        nextReminder: null,
        completedCount: 0
      }
    ]);
    
    // Reset form
    setNewReminder({
      title: '',
      interval: 45,
      duration: 8
    });
  };
  
  const deleteReminder = (id) => {
    setReminders(reminders.filter(reminder => reminder.id !== id));
  };
  
  // Request notification permission
  const requestNotificationPermission = () => {
    if (Notification.permission !== "granted") {
      Notification.requestPermission();
    }
  };
  
  useEffect(() => {
    requestNotificationPermission();
  }, []);
  
  return (
    <div className="interval-reminder">
      <h2>Interval Reminders</h2>
      <p>Set up reminders that repeat at specific intervals throughout the day.</p>
      
      <div className="reminder-form">
        <h3>Add New Reminder</h3>
        <div className="form-group">
          <label>Activity:</label>
          <input 
            type="text" 
            name="title" 
            value={newReminder.title} 
            onChange={handleInputChange} 
            placeholder="e.g., 10 Squats"
          />
        </div>
        
        <div className="form-group">
          <label>Repeat every:</label>
          <input 
            type="number" 
            name="interval" 
            value={newReminder.interval} 
            onChange={handleInputChange} 
            min="1" 
            max="120"
          />
          <span>minutes</span>
        </div>
        
        <div className="form-group">
          <label>For duration of:</label>
          <input 
            type="number" 
            name="duration" 
            value={newReminder.duration} 
            onChange={handleInputChange} 
            min="1" 
            max="24"
          />
          <span>hours</span>
        </div>
        
        <button className="add-button" onClick={addNewReminder}>Add Reminder</button>
      </div>
      
      <div className="reminders-list">
        <h3>Your Reminders</h3>
        {reminders.length === 0 ? (
          <p className="no-reminders">No reminders set up yet.</p>
        ) : (
          <ul>
            {reminders.map(reminder => (
              <li key={reminder.id} className={reminder.active ? 'active' : ''}>
                <div className="reminder-info">
                  <h4>{reminder.title}</h4>
                  <p>Every {reminder.interval} minutes for {reminder.duration} hours</p>
                  {reminder.active && reminder.nextReminder && (
                    <p className="next-reminder">
                      Next reminder: {new Date(reminder.nextReminder).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </p>
                  )}
                  {reminder.active && (
                    <p className="completed-count">
                      Completed: {reminder.completedCount} times
                    </p>
                  )}
                </div>
                <div className="reminder-actions">
                  <button 
                    className={`toggle-button ${reminder.active ? 'active' : ''}`} 
                    onClick={() => toggleReminder(reminder.id)}
                  >
                    {reminder.active ? 'Stop' : 'Start'}
                  </button>
                  <button 
                    className="delete-button" 
                    onClick={() => deleteReminder(reminder.id)}
                  >
                    ×
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default IntervalReminder;
