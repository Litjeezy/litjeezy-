import React from 'react';

// This file contains the SVG code for the HabitHelperPro logo
// The logo represents the concept of habit tracking and interval reminders

const Logo = () => {
  return (
    <svg width="200" height="200" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
      {/* Circular background representing a clock/timer */}
      <circle cx="100" cy="100" r="90" fill="#4CAF50" opacity="0.1" />
      <circle cx="100" cy="100" r="85" stroke="#4CAF50" strokeWidth="5" />
      
      {/* Clock hands representing time management */}
      <line x1="100" y1="100" x2="100" y2="40" stroke="#4CAF50" strokeWidth="6" strokeLinecap="round" />
      <line x1="100" y1="100" x2="140" y2="130" stroke="#4CAF50" strokeWidth="6" strokeLinecap="round" />
      
      {/* Checkmark representing completed habits */}
      <path d="M70 100L90 120L130 80" stroke="#4CAF50" strokeWidth="8" strokeLinecap="round" strokeLinejoin="round" />
      
      {/* Center dot */}
      <circle cx="100" cy="100" r="8" fill="#4CAF50" />
    </svg>
  );
};

export default Logo;
